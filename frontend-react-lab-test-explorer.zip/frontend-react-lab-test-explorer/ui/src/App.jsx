


import Blocks from './components/blocks'
import { ThemeProvider } from '@mui/material/styles';
import theme from './themes/theme'; 
import CssBaseline from '@mui/material/CssBaseline';

function App() {


  return (
    <ThemeProvider theme={theme}>
        <CssBaseline /> 
            <Blocks />
      </ThemeProvider>
  );
}

export default App;
