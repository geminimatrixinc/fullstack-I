import React, { useState } from "react"
import AddressSelector from "./addressSelector";
import Header from './header';
import BlockDetails from "./blockDetails";
import WidgetsIcon from '@mui/icons-material/Widgets';
import { Select, MenuItem, InputLabel, FormControl } from '@mui/material';
import { getMockEtheruemBlocks } from '../helpers/utilities';

function Blocks() {
    const [selectedAddress, setSelectedAddress] = useState(null);

    const ethereumBlocks = getMockEtheruemBlocks(10);
    const ethereumAddresses = ethereumBlocks?.map(a => a.address);

    console.log(`Ethereum Blocks: ${JSON.stringify(ethereumBlocks)}`)
    console.log(`Ethereum Addresses: ${JSON.stringify(ethereumAddresses) }`)

    const [selectedBlock, setSelectedBlock] = useState(null);

    // handlers
    const getBlockByAddress = (address) => {
        return ethereumBlocks.find(b => b.address === address);
    }
   const handleOnChange = (e) => {
        const address = e.target.value;
       console.log(address)
       setSelectedAddress(address);

       var ethereumBlock = getBlockByAddress(address)
       setSelectedBlock(ethereumBlock);
   }



    return(
       <>
            <Header 
                title="Blocks" 
                headerSize="h5" 
                icon={WidgetsIcon}
                />
            {/* <AddressSelector 
                InputLabel="Ethereum Block" 
                LabelId="ethereum-block-select-label" 
                handleAction={ handleOnChange }
                addresses={ethereumAddresses}
                /> */}
            <FormControl fullWidth>
                <InputLabel id="ethereum-block-select-label">
                    Ethereum Block
                </InputLabel>
                <Select
                    labelId="ethereum-block-select"
                    value={selectedAddress}
                    label="Ethereum Block"
                    onChange={handleOnChange}
                >
                    {ethereumAddresses?.map((address) => (
                        <MenuItem key={address} value={address}>{address}</MenuItem>
                    ))}
                </Select>
            </FormControl>
            <div class="container">
                <BlockDetails {...selectedBlock} />
            </div>
       </>
    )

}

export default Blocks;