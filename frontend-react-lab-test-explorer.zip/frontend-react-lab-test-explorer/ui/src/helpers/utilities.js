import { faker } from '@faker-js/faker';
import CryptoJS from 'crypto-js';

export const getRandomNumber = (min = 0, max = 100) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

export const createEthereumNumber = () => {
    return faker.finance.ethereumAddress()
}

export const getMockEtheruemBlocks = (blockNum = 10) => {
    const ethereumBlocks = [];
    for (var i = 0; i < blockNum; i++) {
        ethereumBlocks.push(
            {
                address: createEthereumNumber(),
                balance: getRandomNumber(1, 1000),
                gasUsed: getRandomNumber(1, 5000)
            }
        );
    }
    return ethereumBlocks;
}

export const createCryptoHash = (hashMessage) => {
   return CryptoJS.SHA256(`${hashMessage}${Date.now()}`).toString();
}