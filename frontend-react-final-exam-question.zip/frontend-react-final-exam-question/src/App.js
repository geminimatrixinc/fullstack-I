import './App.css';

function App() {
  return (
    <div className="App">
      <EthereumAddressList />
    </div>
  );
}

export default App;
